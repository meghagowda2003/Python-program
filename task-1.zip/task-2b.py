import jmespath

# JSON data
data = {
    "employees": [
        {"name": "John", "department": "Engineering", "salary": 70000},
        {"name": "Jane", "department": "Marketing", "salary": 50000},
        {"name": "Doe", "department": "Engineering", "salary": 55000},
        {"name": "Alice", "department": "Engineering", "salary": 80000}
    ]
}

# JMESPath expression to filter employees in Engineering with a salary > 60000
expression = 'employees[?department == `Engineerings` && salary > `60000`].name'

# Execute the query
high_salary_engineers = jmespath.search(expression, data)

print("Engineers with salary > 60,000:", high_salary_engineers)
