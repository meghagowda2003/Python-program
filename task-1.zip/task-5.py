import jmespath

# Sample JSON object
data = {
    "students": [
        {"name": "Alice", "grades": {"math": 85, "science": 78}},
        {"name": "Bob", "grades": {"math": 55, "science": 92}},
        {"name": "Charlie", "grades": {"math": 88, "science": 82}},
        {"name": "David", "grades": {"math": 70, "science": 75}}
    ]
}

# JMESPath query to find students with any grade > 80
query = "students[?grades.* > `80`].name"

# Execute the query
result = jmespath.search(query, data)

# Output the result
print(result)
