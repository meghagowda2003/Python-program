import jmespath
#allows you to declaratively specify how to extract elements from a JSON document.
# json data
data = {
    "orders": [
        {"customer": "Alice", "amount": 120.50},
        {"customer": "Bob", "amount": 85.75},
        {"customer": "Alice", "amount": 40.00},
        {"customer": "Alice", "amount": 200.00},
        {"customer": "Bob", "amount": 55.25}
    ]
}
#'orders[?customer == `Bob`].amount'
#This extracts the amount field for all orders where the customer is "Bob".
# JMESPath expression to get the amounts for Bob's orders
expression = 'orders[?customer == `Bob`].amount'#.amount extracts the amounts.
#filters the orders where the customer is "Alice" and retrieves the amount field for those orders.

# Fetch the amounts of Bob's orders
bob_orders = jmespath.search(expression, data)#for jmespath.search
# function applies the expression to the JSON data, returning a list of amounts associated with Bob’s orders.
# Calculate the total of Bob's orders
total_bob_orders = sum(bob_orders) if bob_orders else 0
# function sums all the amounts in the list to get the total order amount for Bob.
print(f"Total amount of Bob's orders: {total_bob_orders}")
