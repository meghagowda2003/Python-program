import jmespath

# JSON data
data = {
    "students": [
        {"name": "Alice", "grades": {"math": 85, "science": 78}},
        {"name": "Bob", "grades": {"math": 55, "science": 92}},
        {"name": "Charlie", "grades": {"math": 88, "science": 82}},
        {"name": "David", "grades": {"math": 70, "science": 75}}
    ]
}

# JMESPath expression to find students with grades > 80 in any subject
# expression = 'students[?name == `Alice`].grades.math'
expression='students[?grades.math>80].name'
# Search for students who meet the condition
students_with_high_grades = jmespath.search(expression, data)
print("Students with grades > 80 in at least one subject:", students_with_high_grades)