import jmespath

data = {
    "employees": [
        {"name": "John", "department": "Engineering", "salary": 70000},
        {"name": "Jane", "department": "Marketing", "salary": 50000},
        {"name": "Doe", "department": "Engineering", "salary": 55000},
        {"name": "Alice", "department": "Engineering", "salary": 80000}
    ]
}

# Define the criteria
expression = 'employees[?department==`Engineering`].name'

# Use jmespath to search the data
result = jmespath.search(expression, data)

print(result)
