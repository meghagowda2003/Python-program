import jmespath
# json data
data = {
    "orders": [
        {"customer": "Alice", "amount": 120.50},
        {"customer": "Bob", "amount": 85.75},
        {"customer": "Alice", "amount": 40.00},
        {"customer": "Alice", "amount": 200.00},
        {"customer": "Bob", "amount": 55.25}
    ]
}

expression = 'orders[?customer == `Alice`].amount'#.amount extracts the amounts.
#filters the orders where the customer is "Alice" and retrieves the amount field for those orders.

# Fetch the amounts of Bob's orders
alice_orders = jmespath.search(expression, data)#for jmespath.search
total_alice_orders = sum(alice_orders) if alice_orders else 0
# function sums all the amounts in the list to get the total order amount for Bob.
print(f"Total amount of Alice's orders: {total_alice_orders}")
