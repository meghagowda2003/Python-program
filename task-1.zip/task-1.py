#Task: Write a Python function to rotate a list to the right by k steps. For example, [1, 2, 3, 4, 5] rotated by 2 steps becomes [4, 5, 1, 2, 3].

def rotate_list(nums, k): #define the function
    # Handle cases where k > len(nums)
    k = k % len(nums)

    # Split the list into two parts
    # The last k elements will be moved to the front
    # The remaining elements will stay in the same order
   
    return nums[k:] + nums[:k]
nums = [1, 2, 13, 14, 5]
k = 3
print(rotate_list(nums, k))  




